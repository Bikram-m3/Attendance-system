//TODO implement login mechanisms here
class LoginRepository {
  Future<bool> login() {
    return Future.value(true);
  }

  Future<void> logout() {
    return Future.value();
  }
}
