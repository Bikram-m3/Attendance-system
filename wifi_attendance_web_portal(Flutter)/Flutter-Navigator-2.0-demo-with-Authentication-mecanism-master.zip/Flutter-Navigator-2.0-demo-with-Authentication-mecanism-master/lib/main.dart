import 'package:flutter/material.dart';

import 'package:navigator_v2_flutter_with_auth/src/app.dart';

void main() {
  runApp(App());
}
