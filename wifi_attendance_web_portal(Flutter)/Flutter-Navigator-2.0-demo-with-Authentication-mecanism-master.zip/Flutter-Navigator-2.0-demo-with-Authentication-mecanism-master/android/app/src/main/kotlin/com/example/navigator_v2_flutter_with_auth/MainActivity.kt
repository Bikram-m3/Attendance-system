package com.example.navigator_v2_flutter_with_auth

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
